# Blue Music

삼성 태블릿/안드로이드에서 로컬 음악을 재생하기 위한 새 Android 프로젝트입니다.

## GitHub Actions로 APK 만들기

1. 이 폴더 **안의 내용 전체**를 GitHub 저장소 루트에 업로드합니다.
2. `Actions` 탭에서 `Build Blue Music APK`를 선택합니다.
3. `Run workflow`를 누릅니다.
4. 성공 후 실행 결과의 `Artifacts`에서 `BlueMusic-debug-apk`를 다운로드합니다.
5. 압축을 풀고 `app-debug.apk`를 태블릿에 설치합니다.

이 저장소는 Gradle Wrapper에 의존하지 않습니다. GitHub Actions가 Gradle 9.6.0을 직접 설치하므로 `gradle-wrapper.jar`가 필요하지 않습니다.

## 주요 기능

- 기기 음악 검색
- 제목/아티스트/앨범 검색
- 제목순/아티스트순 정렬
- 즐겨찾기
- 재생/일시정지/이전/다음
- 셔플/반복
- 탐색(Seek)
- 취침 타이머
- Media3 기반 백그라운드 재생
- 화면 잠금 후 재생
- 시스템 미디어 컨트롤
- Android 13+ 음악 접근 권한

## 주의

실제 삼성 태블릿에서의 실행 결과는 GitHub Actions 빌드 후 설치하여 확인해야 합니다. 이 개발 환경에서는 실제 태블릿 런타임 테스트를 수행할 수 없습니다.
