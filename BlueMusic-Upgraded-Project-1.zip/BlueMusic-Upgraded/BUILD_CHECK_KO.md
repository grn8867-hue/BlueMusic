# Blue Music 빌드 체크

- 기존 My-Music 프로젝트 파일을 소스 기반으로 사용하지 않음.
- AGP 9.4.0 / Gradle 9.6.x / JDK 17 조합.
- Media3 1.11.1 사용.
- GitHub Actions가 실행 시 Gradle Wrapper를 생성한 뒤 APK를 빌드한다.
- 실제 삼성 태블릿에서의 런타임 검증은 이 환경에서 수행할 수 없으므로 100% 무오류를 보장하지 않는다.
