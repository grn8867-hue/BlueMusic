package com.bluemusic.app;

import android.Manifest;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.View;
import android.widget.*;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.session.MediaController;
import androidx.media3.session.SessionToken;
import com.google.common.util.concurrent.ListenableFuture;
import java.util.*;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity implements SongAdapter.Callbacks {
    private List<Song> songs = new ArrayList<>();
    private List<Song> shown = new ArrayList<>();
    private final Set<Long> favorites = new HashSet<>();
    private SongAdapter adapter;
    private EditText search; private TextView empty, nowTitle, nowArtist; private SeekBar seek;
    private ImageButton playButton, shuffleButton, repeatButton;
    private MediaController controller;
    private ListenableFuture<MediaController> controllerFuture;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean favoritesOnly=false;
    private int repeatMode=Player.REPEAT_MODE_OFF;
    private int sortMode=0; // 0 title, 1 artist
    private final Handler sleepHandler = new Handler(Looper.getMainLooper());
    private Runnable sleepTask;

    @Override protected void onCreate(@Nullable Bundle b){
        super.onCreate(b); setContentView(R.layout.activity_main);
        android.content.SharedPreferences p = getSharedPreferences("music", MODE_PRIVATE);
        favorites.clear(); for(String x:p.getStringSet("favorites", Collections.emptySet())) try{favorites.add(Long.parseLong(x));}catch(Exception ignored){}
        bindViews(); setupActions(); requestPermissionsIfNeeded();
    }
    private void bindViews(){
        search=findViewById(R.id.search); empty=findViewById(R.id.empty); nowTitle=findViewById(R.id.nowTitle); nowArtist=findViewById(R.id.nowArtist); seek=findViewById(R.id.seek);
        playButton=findViewById(R.id.btnPlay); shuffleButton=findViewById(R.id.btnShuffle); repeatButton=findViewById(R.id.btnRepeat);
        adapter=new SongAdapter(this,shown,favorites,this); ((ListView)findViewById(R.id.list)).setAdapter(adapter);
    }
    private void setupActions(){
        findViewById(R.id.tabSongs).setOnClickListener(v->{favoritesOnly=false; refreshFilter();});
        findViewById(R.id.tabFavorites).setOnClickListener(v->{favoritesOnly=true; refreshFilter();});
        findViewById(R.id.btnSort).setOnClickListener(v->{sortMode=(sortMode+1)%2; refreshFilter(); Toast.makeText(this,sortMode==0?"제목순":"아티스트순",Toast.LENGTH_SHORT).show();});
        findViewById(R.id.btnSleep).setOnClickListener(v->showSleepMenu());
        shuffleButton.setOnClickListener(v->{if(controller!=null){controller.setShuffleModeEnabled(!controller.getShuffleModeEnabled()); Toast.makeText(this,controller.getShuffleModeEnabled()?"셔플 켜짐":"셔플 꺼짐",Toast.LENGTH_SHORT).show();}});
        repeatButton.setOnClickListener(v->{if(controller==null)return; repeatMode=repeatMode==Player.REPEAT_MODE_OFF?Player.REPEAT_MODE_ALL:repeatMode==Player.REPEAT_MODE_ALL?Player.REPEAT_MODE_ONE:Player.REPEAT_MODE_OFF; controller.setRepeatMode(repeatMode); Toast.makeText(this,repeatMode==Player.REPEAT_MODE_OFF?"반복 꺼짐":repeatMode==Player.REPEAT_MODE_ALL?"전체 반복":"한 곡 반복",Toast.LENGTH_SHORT).show();});
        playButton.setOnClickListener(v->{if(controller!=null){if(controller.isPlaying())controller.pause();else controller.play();}});
        findViewById(R.id.btnPrev).setOnClickListener(v->{if(controller!=null)controller.seekToPrevious();});
        findViewById(R.id.btnNext).setOnClickListener(v->{if(controller!=null)controller.seekToNext();});
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean from){if(from&&controller!=null&&controller.getDuration()>0)controller.seekTo((controller.getDuration()*p)/1000L);} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}});
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){refreshFilter();} public void afterTextChanged(android.text.Editable e){}});
    }
    private void requestPermissionsIfNeeded(){
        ArrayList<String> req=new ArrayList<>();
        if(android.os.Build.VERSION.SDK_INT>=33){if(ContextCompat.checkSelfPermission(this,Manifest.permission.READ_MEDIA_AUDIO)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.READ_MEDIA_AUDIO); if(ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.POST_NOTIFICATIONS);}
        else if(ContextCompat.checkSelfPermission(this,Manifest.permission.READ_EXTERNAL_STORAGE)!=PackageManager.PERMISSION_GRANTED)req.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        if(req.isEmpty())loadSongs(); else requestPermissions(req.toArray(new String[0]), 1001);
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults){
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==1001) {
            boolean audioOk = android.os.Build.VERSION.SDK_INT >= 33 ? ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_AUDIO)==PackageManager.PERMISSION_GRANTED : ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)==PackageManager.PERMISSION_GRANTED;
            if(audioOk) loadSongs(); else empty.setText("음악 접근 권한이 필요합니다. 설정에서 권한을 허용해 주세요.");
        }
    }
    private void loadSongs(){
        new Thread(()->{
            ArrayList<Song> out=new ArrayList<>(); Uri uri=MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
            String[] projection={MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST,MediaStore.Audio.Media.ALBUM};
            String sel=MediaStore.Audio.Media.IS_MUSIC+" != 0"; String sort=MediaStore.Audio.Media.TITLE+" COLLATE NOCASE ASC";
            try(Cursor c=getContentResolver().query(uri,projection,sel,null,sort)){if(c!=null){int id=c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);int ti=c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE);int ar=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);int al=c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);while(c.moveToNext()){long x=c.getLong(id);String title=nonEmpty(c.getString(ti),"알 수 없는 곡");String artist=nonEmpty(c.getString(ar),"알 수 없는 아티스트");String album=nonEmpty(c.getString(al),"알 수 없는 앨범");out.add(new Song(x,title,artist,album,Uri.withAppendedPath(uri,Long.toString(x))));}}}
            catch(SecurityException e){}
            runOnUiThread(()->{songs=out;refreshFilter();empty.setText(out.isEmpty()?"기기에 음악이 없거나 음악 권한이 필요합니다.":"");});
        }).start();
    }
    private String nonEmpty(String s,String d){return s==null||s.trim().isEmpty()?d:s;}
    private void refreshFilter(){
        String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.getDefault()); ArrayList<Song> x=new ArrayList<>();
        for(Song s:songs){if(favoritesOnly&&!favorites.contains(s.id))continue; if(!q.isEmpty()&&!((s.title+" "+s.artist+" "+s.album).toLowerCase(Locale.getDefault()).contains(q)))continue;x.add(s);}
        x.sort((a,b)->sortMode==0?a.title.compareToIgnoreCase(b.title):a.artist.compareToIgnoreCase(b.artist));
        shown=x; if(adapter!=null)adapter.setData(shown); if(empty!=null&&songs.size()>0)empty.setText(shown.isEmpty()?"검색 결과가 없습니다.":"");
    }
    @Override public void play(Song s){
        ensureController(()->{ArrayList<MediaItem> items=new ArrayList<>();for(Song x:songs){items.add(toMediaItem(x));}int idx=0;for(int i=0;i<songs.size();i++)if(songs.get(i).id==s.id){idx=i;break;}controller.setMediaItems(items,idx,0);controller.prepare();controller.play();updateNow(s);});
    }
    private MediaItem toMediaItem(Song s){MediaMetadata md=new MediaMetadata.Builder().setTitle(s.title).setArtist(s.artist).setAlbumTitle(s.album).build();return new MediaItem.Builder().setMediaId(Long.toString(s.id)).setUri(s.uri).setMediaMetadata(md).build();}
    private void ensureController(Runnable after){
        if(controller!=null){after.run();return;}
        if(controllerFuture!=null){controllerFuture.addListener(()->{try{controller=controllerFuture.get();attachPlayer();after.run();}catch(Exception e){Toast.makeText(this,"재생 서비스 연결에 실패했습니다.",Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));return;}
        SessionToken token=new SessionToken(this,new ComponentName(this,PlaybackService.class)); controllerFuture=new MediaController.Builder(this,token).buildAsync();
        controllerFuture.addListener(()->{try{controller=controllerFuture.get();attachPlayer();after.run();}catch(ExecutionException e){Toast.makeText(this,"재생 서비스 연결에 실패했습니다.",Toast.LENGTH_LONG).show();controllerFuture=null;}catch(Exception e){Toast.makeText(this,"재생 준비 중 오류가 발생했습니다.",Toast.LENGTH_LONG).show();controllerFuture=null;}},ContextCompat.getMainExecutor(this));
    }
    private void attachPlayer(){controller.addListener(new Player.Listener(){@Override public void onIsPlayingChanged(boolean p){playButton.setImageResource(p?android.R.drawable.ic_media_pause:android.R.drawable.ic_media_play);}@Override public void onMediaItemTransition(@Nullable MediaItem item,int reason){if(item!=null){Song s=findSong(item.mediaId);if(s!=null)updateNow(s);}}});}
    private Song findSong(String id){try{long x=Long.parseLong(id);for(Song s:songs)if(s.id==x)return s;}catch(Exception ignored){}return null;}
    private void updateNow(Song s){nowTitle.setText(s.title);nowArtist.setText(s.artist); getSharedPreferences("music",MODE_PRIVATE).edit().putLong("lastSong",s.id).apply();}
    @Override public void toggleFavorite(Song s){if(favorites.contains(s.id))favorites.remove(s.id);else favorites.add(s.id);HashSet<String> out=new HashSet<>();for(Long x:favorites)out.add(Long.toString(x));getSharedPreferences("music",MODE_PRIVATE).edit().putStringSet("favorites",out).apply();refreshFilter();}
    private final Runnable ticker=new Runnable(){@Override public void run(){if(controller!=null&&controller.getDuration()>0){long d=controller.getDuration(),p=controller.getCurrentPosition();seek.setProgress((int)Math.max(0,Math.min(1000,(p*1000)/d)));}handler.postDelayed(this,500);}};
    @Override protected void onStart(){super.onStart();handler.post(ticker);}
    @Override protected void onStop(){handler.removeCallbacks(ticker);super.onStop();}
    private void showSleepMenu(){
        final String[] items={"끄기","15분","30분","60분"};
        new android.app.AlertDialog.Builder(this).setTitle("취침 타이머").setItems(items,(d,w)->{ if(sleepTask!=null)sleepHandler.removeCallbacks(sleepTask); if(w>0){long ms=new long[]{0,15*60_000L,30*60_000L,60*60_000L}[w]; sleepTask=()->{if(controller!=null)controller.pause(); Toast.makeText(this,"재생이 일시정지되었습니다.",Toast.LENGTH_SHORT).show();}; sleepHandler.postDelayed(sleepTask,ms); Toast.makeText(this,items[w]+" 후 일시정지",Toast.LENGTH_SHORT).show();} else Toast.makeText(this,"취침 타이머 꺼짐",Toast.LENGTH_SHORT).show(); }).show();
    }
    @Override protected void onDestroy(){if(sleepTask!=null)sleepHandler.removeCallbacks(sleepTask);if(controller!=null){MediaController.releaseFuture(controllerFuture);controller=null;}super.onDestroy();}
}
