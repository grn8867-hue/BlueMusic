package com.bluemusic.app;

import android.net.Uri;

public final class Song {
    public final long id;
    public final String title, artist, album;
    public final Uri uri;
    public Song(long id, String title, String artist, String album, Uri uri) {
        this.id=id; this.title=title; this.artist=artist; this.album=album; this.uri=uri;
    }
}
