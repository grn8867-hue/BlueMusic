package com.bluemusic.app;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.util.List;
import java.util.Set;

public final class SongAdapter extends BaseAdapter {
    public interface Callbacks { void play(Song s); void toggleFavorite(Song s); }
    private final LayoutInflater inflater; private List<Song> data; private final Set<Long> favorites; private final Callbacks callbacks;
    public SongAdapter(android.content.Context c, List<Song> data, Set<Long> favorites, Callbacks callbacks){this.inflater=LayoutInflater.from(c);this.data=data;this.favorites=favorites;this.callbacks=callbacks;}
    public void setData(List<Song> d){data=d;notifyDataSetChanged();}
    @Override public int getCount(){return data.size();} @Override public Song getItem(int p){return data.get(p);} @Override public long getItemId(int p){return data.get(p).id;}
    @Override public View getView(int p, View convert, ViewGroup parent){
      View v=convert==null?inflater.inflate(com.bluemusic.app.R.layout.row_music,parent,false):convert; Song s=getItem(p);
      TextView t=v.findViewById(R.id.title), a=v.findViewById(R.id.artist), f=v.findViewById(R.id.fav); t.setText(s.title); a.setText(s.artist); t.setTypeface(null, Typeface.BOLD); f.setText(favorites.contains(s.id)?"♥":"♡");
      v.setOnClickListener(x->callbacks.play(s)); f.setOnClickListener(x->callbacks.toggleFavorite(s)); return v;
    }
}
