# Blue Music

완전히 새로 작성한 Android 음악 플레이어 프로젝트입니다. 기존 My-Music 프로젝트의 소스/리소스를 사용하지 않습니다.

## 포함 기능
- 기기 음악 자동 검색
- 검색
- 모든 음악 / 좋아요 필터
- 즐겨찾기 저장
- 재생 / 일시정지 / 이전 / 다음
- 셔플 / 전체 반복 / 한 곡 반복
- 탐색(SeekBar)
- Media3 ExoPlayer 기반 재생
- MediaSessionService 기반 백그라운드 재생
- 화면이 꺼진 상태 재생
- 시스템 미디어 컨트롤/블루투스 미디어 버튼
- Android 13+ 음악 및 알림 권한 처리
- GitHub Actions에서 APK 자동 빌드

## 태블릿에서 APK 만들기
1. GitHub에 새 저장소를 만듭니다.
2. 이 프로젝트의 파일과 폴더를 저장소 루트에 업로드합니다.
3. Actions 탭에서 `Build Blue Music APK`를 실행합니다.
4. 작업이 끝나면 Artifacts에서 `BlueMusic-debug-apk`를 내려받습니다.

이 프로젝트는 로컬 Gradle Wrapper JAR을 포함하지 않습니다. 대신 GitHub Actions가 Gradle 9.6.1을 설치하고 wrapper를 생성한 뒤 빌드합니다. 따라서 이전 프로젝트에서 발생했던 wrapper JAR 누락 문제를 반복하지 않습니다.
